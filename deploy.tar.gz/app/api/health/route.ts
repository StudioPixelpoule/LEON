
import { NextResponse } from 'next/server'
import fs from 'fs'

export const dynamic = 'force-dynamic'

export async function GET() {
  const startTime = process.uptime()
  const checks = {
    app: 'ok',
    media_path: false,
    env_vars: false
  }

  // 1. Vérification du dossier médias
  const mediaPath = process.env.PCLOUD_LOCAL_PATH || '/leon/media/films'
  try {
    if (fs.existsSync(mediaPath)) {
      checks.media_path = true
    }
  } catch (e) {
    console.error('Healthcheck: Media path access error', e)
  }

  // 2. Vérification des variables d'environnement critiques
  if (process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.SUPABASE_SERVICE_KEY) {
    checks.env_vars = true
  }

  // Détermination du statut global
  const isHealthy = checks.app === 'ok' && checks.env_vars
  // Note: On met media_path en warning (degraded) plutôt qu'unhealthy car le montage peut être vide au début
  const status = isHealthy ? (checks.media_path ? 'healthy' : 'degraded') : 'unhealthy'

  return NextResponse.json(
    {
      status,
      timestamp: new Date().toISOString(),
      uptime: Math.floor(startTime),
      checks,
      env: {
        node_env: process.env.NODE_ENV,
        media_path_configured: mediaPath
      }
    },
    { status: status === 'unhealthy' ? 503 : 200 }
  )
}


